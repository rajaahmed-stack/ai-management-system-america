from datetime import datetime
from typing import Dict, Any, List

class User:
    def __init__(self, user_data: Dict[str, Any]):
        self.id = user_data.get('id')
        self.email = user_data.get('email')
        self.name = user_data.get('name')
        self.industry = user_data.get('industry')
        self.role = user_data.get('role')
        self.organization_id = user_data.get('organization_id')
        self.permissions = user_data.get('permissions', [])
        self.created_at = user_data.get('created_at', datetime.now())
        self.updated_at = user_data.get('updated_at', datetime.now())
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'email': self.email,
            'name': self.name,
            'industry': self.industry,
            'role': self.role,
            'organization_id': self.organization_id,
            'permissions': self.permissions,
            'created_at': self.created_at,
            'updated_at': self.updated_at
        }
    
    def has_permission(self, permission: str) -> bool:
        return permission in self.permissions

class Organization:
    def __init__(self, org_data: Dict[str, Any]):
        self.id = org_data.get('id')
        self.name = org_data.get('name')
        self.industry = org_data.get('industry')
        self.admin_id = org_data.get('admin_id')
        self.settings = org_data.get('settings', {})
        self.subscription = org_data.get('subscription', 'basic')
        self.created_at = org_data.get('created_at', datetime.now())
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'industry': self.industry,
            'admin_id': self.admin_id,
            'settings': self.settings,
            'subscription': self.subscription,
            'created_at': self.created_at
        }