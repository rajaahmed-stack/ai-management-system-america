import firebase_admin
from firebase_admin import credentials, firestore

# Global database instance
db = None

def initialize_firebase():
    global db
    if not firebase_admin._apps:
        cred = credentials.Certificate("nexus-ai-app-e1df1-firebase-adminsdk-fbsvc-32089d5d4f.json")
        firebase_admin.initialize_app(cred)
        db = firestore.client()
        print("✅ Firebase initialized successfully")
    return db

def get_db():
    global db
    if db is None:
        return initialize_firebase()
    return db